# Student-Arrangement-Program
This is a program that seats students in a certian way during the Summer Math sessions.